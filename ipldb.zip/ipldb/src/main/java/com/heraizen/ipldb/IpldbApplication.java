package com.heraizen.ipldb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpldbApplication {

	public static void main(String[] args) {
		SpringApplication.run(IpldbApplication.class, args);
	}

}
