package com.heraizen.ipldb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpldbApplicationTests {

	@Test
	void contextLoads() {
	}

}
