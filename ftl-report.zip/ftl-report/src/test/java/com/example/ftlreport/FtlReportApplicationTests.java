package com.example.ftlreport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FtlReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
