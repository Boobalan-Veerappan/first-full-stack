package com.example.ftlreport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FtlReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(FtlReportApplication.class, args);
	}

}
