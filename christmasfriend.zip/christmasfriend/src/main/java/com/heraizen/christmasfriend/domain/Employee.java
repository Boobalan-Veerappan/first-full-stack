package com.heraizen.christmasfriend.domain;



import lombok.Builder;
import lombok.Data;

@Data
@Builder

public class Employee {

	private String EmpNo;
	private String Name;
	private String Address;
	private String Email;
}
