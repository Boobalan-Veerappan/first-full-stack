package com.heraizen.christmasfriend;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.heraizen.christmasfriend.domain.Employee;




@Configuration
@RestController
@RequestMapping("/api/christmas/")
public class SampleController {

	
	@Autowired
	private christmas christmas;
	
	
	@Bean
	@GetMapping("christmas")
	
	public HashMap<Employee, Employee> christmasFriendList()  {
		
		
		
		
		return null;
		
		
	}
	
}
