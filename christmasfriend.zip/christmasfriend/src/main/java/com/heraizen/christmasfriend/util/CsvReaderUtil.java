package com.heraizen.christmasfriend.util;



import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.heraizen.christmasfriend.domain.Employee;





public class CsvReaderUtil {

	private static final String FILE_NAME = "christmasfrnd.csv";

	private CsvReaderUtil() {
	}

	public static List<Employee> readDataFromFile() {
		List<Employee> studentList = new ArrayList<>();
		try {
			List<String> list = Files.readAllLines(Paths.get(ClassLoader.getSystemResource(FILE_NAME).toURI()));
			studentList = list.stream().skip(1).map(row -> convertRowToEmployee(row)).collect(Collectors.toList());
		} catch (IOException | URISyntaxException e) {
			System.out.println("While reading csv file: " + e);
		}
		return studentList;
	}
	
	private static Employee convertRowToEmployee(String row) {
		String[] data = row.split(",");
		int i = 0;
		
		String empNo=data[i++];
		String name=data[i++];
		String address=data[i++];
		String email=data[i++];

		Employee employee=Employee.builder().EmpNo(empNo).Name(name).Address(address).Email(email).build();
		return employee;
	}
	
}
