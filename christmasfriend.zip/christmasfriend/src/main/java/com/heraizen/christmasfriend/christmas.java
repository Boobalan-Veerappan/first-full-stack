package com.heraizen.christmasfriend;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.heraizen.christmasfriend.domain.Employee;
import com.heraizen.christmasfriend.util.CsvReaderUtil;


import freemarker.template.Configuration;
import freemarker.template.Template;


@Component
public class christmas {
	
	@Autowired
	private Configuration cfg;

	List<Employee> employee = CsvReaderUtil.readDataFromFile();
	





}
