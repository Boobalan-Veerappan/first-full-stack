package com.heraizen.ipldbconnection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpldbconnectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
