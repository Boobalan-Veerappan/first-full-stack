package com.heraizen.iplstat.dao;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.heraizen.iplstat.domain.Team;
import com.heraizen.iplstat.dto.LabelDto;
import com.heraizen.iplstat.dto.PlayerAmountDTO;
import com.heraizen.iplstat.dto.PlayerDto;
import com.heraizen.iplstat.dto.RoleAmountDTO;
import com.heraizen.iplstat.dto.RolesDTO;
import com.heraizen.iplstat.dto.TeamDetailsDTO;
import com.heraizen.iplstat.util.SeedDataUtil;

@SpringBootTest
public class IplStatDaoImplTest {

	@Autowired
	private IplStatDao iplStatDao;

	@BeforeEach
	void init() {
		iplStatDao.removeall();
		List<Team> teams = SeedDataUtil.loadFromJSON();
		iplStatDao.insertTeam(teams);
		
	}

	@Test
	void testFindLabels() {
		
		
		
		LabelDto labelDto = iplStatDao.findTeamLabels();
		
		System.out.println("SDFFFFFFFFFFFFFFsfsdddd"+iplStatDao.findTeamLabels());
		assertThat(labelDto.getLabels(), hasSize(8));
	}

	@Test
	void testFindPlayerByLabel() {
		String label = "RCB";
		
		List<PlayerDto> playersList = iplStatDao.findPlayerByLabel(label);
		assertThat(playersList, hasSize(42));
	}
	
	@Test
	void testfind()
	{
		List<PlayerAmountDTO> roo =	iplStatDao.PlayerBysalary();
		PlayerAmountDTO name = roo.get(0);
		System.out.println("@@@@@@"+name.getName());
		assertEquals(name.getName(), "Virat Kohli (R)");
		
	}
	
	@Test
	void testTotalteamDetails()
	{
		List<TeamDetailsDTO> details = iplStatDao.TeamDetails();
		TeamDetailsDTO team = details.get(1);
		String city="Delhi, NCR";
		assertEquals(team.getCity(), city);
	}
	
	@Test
	void testAmountbyLabel()
	{
		List<RoleAmountDTO> details = iplStatDao.RoleAmountbyLabel("CSK");
		
	}
	
//	@Test
//	void testfindroles() {
//		String label = "CSK";
//		List<RolesDTO> role = iplStatDao.RoleCountByLabel(label);
//		
//		
//	}
}


