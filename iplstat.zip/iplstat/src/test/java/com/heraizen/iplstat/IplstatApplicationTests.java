package com.heraizen.iplstat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplstatApplicationTests {

	@Test
	void contextLoads() {
	}

}
