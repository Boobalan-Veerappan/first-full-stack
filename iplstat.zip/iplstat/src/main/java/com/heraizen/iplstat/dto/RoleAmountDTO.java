package com.heraizen.iplstat.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RoleAmountDTO {

	
	String role;
	long Amount;
}
