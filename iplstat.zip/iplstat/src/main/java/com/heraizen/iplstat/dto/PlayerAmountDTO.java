package com.heraizen.iplstat.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PlayerAmountDTO {
String name;
String label;
long price;
String role;
}
