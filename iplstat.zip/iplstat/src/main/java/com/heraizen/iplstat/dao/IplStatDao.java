package com.heraizen.iplstat.dao;

import java.util.List;

import com.heraizen.iplstat.domain.Team;
import com.heraizen.iplstat.dto.LabelDto;
import com.heraizen.iplstat.dto.PlayerAmountDTO;
import com.heraizen.iplstat.dto.PlayerDto;
import com.heraizen.iplstat.dto.RoleAmountDTO;
import com.heraizen.iplstat.dto.RolesDTO;
import com.heraizen.iplstat.dto.TeamDetailsDTO;

public interface IplStatDao {

	

public List<RolesDTO> RoleCountByLabel(String label);
	public LabelDto findTeamLabels();
	public List<PlayerDto> findPlayerByLabel(String label);

	public List<Team> insertTeam(List<Team> teams);
	public void removeall();
	
	public List<PlayerAmountDTO> PlayerBysalary();
	
	
	public List<TeamDetailsDTO> TeamDetails();
	
	public List<RoleAmountDTO> RoleAmountbyLabel(String label);
}
