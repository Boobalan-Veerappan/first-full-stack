package com.heraizen.iplstat.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TeamDetailsDTO {

	
	String homeGround;
	String label;
	String coach;
	String name;
	String city;
	
}
