package com.heraizen.iplstat.dao;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.unwind;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;
import static com.mongodb.client.model.Sorts.descending;
import static com.mongodb.client.model.Aggregates.sort;
import com.heraizen.iplstat.domain.Team;
import com.heraizen.iplstat.dto.LabelDto;
import com.heraizen.iplstat.dto.PlayerAmountDTO;
import com.heraizen.iplstat.dto.PlayerDto;
import com.heraizen.iplstat.dto.RoleAmountDTO;
import com.heraizen.iplstat.dto.RolesDTO;
import com.heraizen.iplstat.dto.TeamDetailsDTO;
import com.heraizen.iplstat.repo.IplTeamRepo;

@Repository
public class IplStatDaoImpl implements IplStatDao {

	private Logger log = LoggerFactory.getLogger(IplStatDaoImpl.class);
	int i=0;
	@Autowired
	private IplTeamRepo iplteam; 
	@Autowired
	private MongoOperations monogoOperations;

	public List<Team> insertTeam(List<Team> teams)
	{
		return iplteam.saveAll(teams);
	}

	@Override
	public LabelDto findTeamLabels() {
		Aggregation query = newAggregation(group("null").addToSet("label").as("labels"), project().andExclude("_id"));
		AggregationResults<LabelDto> result = monogoOperations.aggregate(query, "team", LabelDto.class);
		
		
		
		return result.getUniqueMappedResult();
	}

	@Override
	public List<PlayerDto> findPlayerByLabel(String label) {
	
		MatchOperation match = match(Criteria.where("label").is(label));
		UnwindOperation unwind = unwind("players");
		ProjectionOperation project = project().and("players.name").as("name").and("players.role").as("role")
				.and("players.price").as("price").and("label").as("label").andExclude("_id");
		Aggregation query = newAggregation(match, unwind, project);
		log.debug("Generated query :{}", query);
		AggregationResults<PlayerDto> result = monogoOperations.aggregate(query, "team", PlayerDto.class);
		List<PlayerDto> playerDtos = result.getMappedResults();
		log.info("Total {} players found for the given label: {}", playerDtos.size(), label);
		return playerDtos;
	}

	@Override
	public List<RolesDTO> RoleCountByLabel(String label) {
		MatchOperation match = match(Criteria.where("label").is(label));
		UnwindOperation unwind = unwind("players");
		GroupOperation group = Aggregation.group("label").count().as("count");
		ProjectionOperation project = project().and("_id").as("label")
				.and("count").as("count").and("_id.role").as("role").andExclude("_id");
		Aggregation query = newAggregation(match,unwind,group,project);
		log.debug("Generated query :{}", query);
		AggregationResults<RolesDTO> result = monogoOperations.aggregate(query, "team", RolesDTO.class);
		List<RolesDTO> playerDtos = result.getMappedResults();
		log.info("Total {} players found for the given label: {}", playerDtos, label);
		return playerDtos;
	}

	
	
	
	
	public void removeall()
	{
		iplteam.deleteAll();
	}

	@Override
	public List<PlayerAmountDTO> PlayerBysalary() {
		
		UnwindOperation unwind = unwind("players");
		SortOperation sort = sort(Sort.by(Direction.DESC, "players.price"));
		ProjectionOperation project = project().and("players.name").as("name")
				.and("label").as("label").and("players.price").as("price").and("players.role").as("role").andExclude("_id");
		Aggregation query = newAggregation(unwind,sort,project);
		AggregationResults<PlayerAmountDTO> result = monogoOperations.aggregate(query, "team", PlayerAmountDTO.class);
		List<PlayerAmountDTO> roo = result.getMappedResults();
//		roo.forEach(e->{
//			
//			System.out.println(e.getName());
//		});
		return roo;
	}

	@Override
	public List<TeamDetailsDTO> TeamDetails() {
		
		ProjectionOperation project = project().and("home").as("homeGround").and("label").as("label")
				.and("coach").as("coach").and("name").as("name").and("city").as("city").andExclude("_id");
		
		Aggregation query = newAggregation(project);
		AggregationResults<TeamDetailsDTO> result = monogoOperations.aggregate(query, "team", TeamDetailsDTO.class);
		List<TeamDetailsDTO> details = result.getMappedResults();
		
//		details.forEach(e->{
//			i++;
//			System.out.println(e.getCity()+i);
//			
//		});
		
		return details;
	}

	@Override
	public List<RoleAmountDTO> RoleAmountbyLabel(String label) {
		MatchOperation match = match(Criteria.where("label").is(label));
		UnwindOperation unwind = unwind("players");
		GroupOperation group = Aggregation.group("players.role").sum("players.price").as("player");
		ProjectionOperation project = project()
				.and("_id").as("role").and("player").as("amount").andExclude("_id");
		Aggregation query = newAggregation(match,unwind,group,project);
		AggregationResults<RoleAmountDTO> result = monogoOperations.aggregate(query, "team", RoleAmountDTO.class);
		List<RoleAmountDTO> details = result.getMappedResults();
		
		details.forEach(e->{
		i++;
		System.out.println(e.getRole());
		
	});
		
		
		return null;
	}

	

}
