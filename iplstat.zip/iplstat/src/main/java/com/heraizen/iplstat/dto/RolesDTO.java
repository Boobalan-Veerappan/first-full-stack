package com.heraizen.iplstat.dto;

public class RolesDTO {

	String role;
	String label;
	long count;
	
}
