package com.heraizen.iplstat.domain;

import lombok.Data;

@Data
public class Player {

		private String name;
		private String role;
		private double price;
}
