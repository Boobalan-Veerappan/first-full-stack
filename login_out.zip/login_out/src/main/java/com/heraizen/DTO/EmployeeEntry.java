package com.heraizen.DTO;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EmployeeEntry {

	public String id;
	
	public String time;
	
}
