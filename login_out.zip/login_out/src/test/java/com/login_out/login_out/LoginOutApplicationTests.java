package com.login_out.login_out;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginOutApplicationTests {

	@Test
	void contextLoads() {
	}

}
